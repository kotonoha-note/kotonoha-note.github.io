# ことのはノート — GitHub Pages公開用

用語と意味から暗記カード、小テスト、印刷用プリントを作る、無料・登録不要の学習ツールです。サーバーや追加ライブラリは使いません。1つのノートは最大200語、ブラウザごとに最大30冊保存できます。

## GitHub Pagesで公開する手順

初めての公開は、画面が見やすくフォルダを扱いやすいMacがおすすめです。ZIPファイルは、GitHubにそのままアップロードせず、先に展開してください。

1. GitHubに新しい **Public（公開）** リポジトリを作成します。名前は例えば `kotonoha-note`。この手順では、標準のブランチ名が `main` であることを前提にしています。
2. 展開したファイルの**中身**をリポジトリの一番上に追加します。`site`、`scripts`、`tests`、`.github`の各フォルダと、`README.md`などを入れてください。ZIPファイルそのものや、フォルダを丸ごと一段上の名前付きフォルダに入れないでください。
3. リポジトリの **Settings → Pages → Build and deployment → Source** を **GitHub Actions** にします。
4. **Actions → Publish GitHub Pages** を確認します。まだ実行されていなければ、**Run workflow → main → Run workflow** を選びます。完了したら **Settings → Pages** に公開URLが表示されます。

アップロード後に、リポジトリの中に `site/index.html` と `.github/workflows/pages.yml` があることを確認してください。どちらも必要です。リポジトリが `main` 以外のブランチを使う場合は、`.github/workflows/pages.yml` の `branches: [main]` を実際のブランチ名に変更してください。

### `.github` フォルダが見えない場合

名前が `.` から始まるフォルダは端末によって隠れます。MacのFinderでは **Command + Shift + .（ピリオド）** で表示を切り替えられます。

表示やアップロードが難しい場合は、`site`、`scripts`、`tests`、`README.md`、`github-actions-workflow.txt` を先に追加してから、GitHub上で **Add file → Create new file** を選び、名前に `.github/workflows/pages.yml` と入力します。このZIP内の `github-actions-workflow.txt` の内容をすべてコピーして貼り付け、コミットしてください。2つのファイルの内容は同じです。

GitHub Actionsが公開時にURLを取得し、検索向けのcanonical、SNS向けの画像URL、サイトマップを公開先に合わせて生成します。ソース中の `__SITE_URL__` は自動置換用です。元の `site` フォルダを「Deploy from a branch」で直接公開せず、このワークフローを使ってください。

## 作ったノートの保存について

ノートと「覚えた」記録は端末のブラウザ内に保存されます。ブラウザのデータ消去や端末の変更で失われることがあるため、「保存したノート」からJSONにバックアップしてください。テスト中の回答は再読み込みするとリセットされます。

**試作品からGitHubのサイトへは、自動でノートが移りません。** サイトのURLが変わるとブラウザの保存先も分かれるためです。旧サイトでファイルを書き出し、新サイトの「保存したノート → ファイルを読み込む」から移せます。読み込みは既存のノートを上書きせず追加します。

## 主なファイル

| ファイル | 内容 |
| --- | --- |
| `site/index.html` | 学習画面、使い方、FAQ |
| `site/app.js` | ノート、暗記カード、小テスト、印刷の動作 |
| `site/core.js` | 入力の読み取りや採点の共通処理 |
| `site/style.css` | スマホ・PC・印刷時の表示 |
| `site/about.html`、`privacy.html`、`terms.html` | サイト説明、データの扱い、利用上の注意 |
| `scripts/build.mjs` | GitHub PagesのURLに合わせた公開ファイルの生成 |
| `.github/workflows/pages.yml` | 自動テストと公開 |

## 確認と運用

- `node --test tests/*.test.cjs` で入力、採点、バックアップ、GitHub Pages用URLを確認できます。Node.js 22を想定しています。
- ローカルの公開ファイルを作る場合は `node scripts/build.mjs https://example.github.io/kotonoha-note` を実行します。生成先は `_site` です。URLは実際の公開先に合わせてください。
- GitHub PagesのURLが `https://ユーザー名.github.io/リポジトリ名/` の形の場合、作成されたサイトマップはそのURLの末尾に `sitemap.xml` を付けた場所にあります。必要に応じてGoogle Search Consoleに送信できます。
- `robots.txt` が有効なのはホストのルートに置かれた場合だけなので、リポジトリ名のあるサブパス向けには生成しません。別サイトのルート設定も変更しません。
- 広告やアクセス解析のタグは含めていません。追加する場合は、実際の設定に合わせてデータの扱いの説明も更新してください。
- 内容は利用者が入力します。AIによる文章や画像の自動解析、内容の正誤判定はありません。選択式の候補は同じノートの用語から作ります。
- 作成時は主要操作、旧形式ファイルの読み込み、印刷内容、狭い画面幅を確認しています。iPhone実機と紙への実印刷は公開前に確認してください。

参考： [GitHub Pagesの公開設定](https://docs.github.com/ja/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)、[ファイルをリポジトリに追加](https://docs.github.com/ja/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)、[サイトマップを作成・送信](https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap?hl=ja)。
