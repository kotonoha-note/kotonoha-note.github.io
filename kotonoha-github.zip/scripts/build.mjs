import { cp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sourceDir = join(projectRoot, 'site');
const outputDir = join(projectRoot, '_site');
const input = process.env.PAGES_BASE_URL || process.argv[2];
if (!input) {
  console.error('公開先URLが必要です。PAGES_BASE_URLを設定するか、引数にURLを渡してください。');
  process.exit(1);
}

let url;
try { url = new URL(input); }
catch { console.error('公開先URLが正しくありません。'); process.exit(1); }
if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
  console.error('公開先には、認証情報・クエリ・ハッシュを含まないHTTP(S) URLを指定してください。');
  process.exit(1);
}
const siteUrl = url.href.replace(/\/+$/, '');
const encoded = siteUrl.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

await rm(outputDir, { recursive: true, force: true });
await mkdir(outputDir, { recursive: true });
for (const entry of await readdir(sourceDir, { withFileTypes: true })) {
  if (!entry.isFile()) throw new Error(`想定外のフォルダです: ${entry.name}`);
  const src = join(sourceDir, entry.name), dest = join(outputDir, entry.name);
  if (!/\.(html|xml)$/.test(entry.name)) { await cp(src, dest); continue; }
  let data = await readFile(src, 'utf8');
  // JSON-LDはHTML属性と違うエスケープが必要なため、構造を保持したまま更新します。
  data = data.replace(/(<script type="application\/ld\+json">)([\s\S]*?)(<\/script>)/g, (_, open, json, close) => {
    const value = JSON.parse(json.replaceAll('__SITE_URL__', siteUrl));
    return open + JSON.stringify(value).replaceAll('<', '\\u003c') + close;
  });
  data = data.replaceAll('__SITE_URL__', encoded);
  if (data.includes('__SITE_URL__')) throw new Error(`URLの置換に失敗しました: ${entry.name}`);
  await writeFile(dest, data, 'utf8');
}
// robots.txtが検索エンジンに有効なのはホストのルートにあるときだけです。
if (url.pathname === '/') {
  await writeFile(join(outputDir, 'robots.txt'), `User-agent: *\nAllow: /\nSitemap: ${siteUrl}/sitemap.xml\n`, 'utf8');
}
console.log(`GitHub Pages用のファイルを用意しました: ${siteUrl}/`);
