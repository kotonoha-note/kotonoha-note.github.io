const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const build = path.join(root, 'scripts', 'build.mjs');
function run(base) { return spawnSync(process.execPath, [build], {cwd:root, env:{...process.env, PAGES_BASE_URL:base}, encoding:'utf8'}); }
function text(file) { return fs.readFileSync(path.join(root, '_site', file), 'utf8'); }
function confirmHtml(base) {
  for (const name of ['index.html', 'about.html', 'privacy.html', 'terms.html', 'sitemap.xml']) {
    const content=text(name);
    assert.ok(content.includes(base),name);
    assert.ok(!content.includes('__SITE_URL__'),name);
    assert.ok(!content.includes('astralacorn11.chatgpt.site'),name);
  }
  const home=text('index.html');
  assert.match(home,new RegExp(`<link rel="canonical" href="${base.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}/">`));
  const ld=home.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/);
  assert.equal(JSON.parse(ld[1]).url,base+'/');
  for (const file of ['app.js','core.js','style.css','favicon.svg','og.png','icon-180.png']) assert.ok(fs.existsSync(path.join(root,'_site',file)),file);
}
test('project repository URLs include the repository name', () => {
  const base='https://example.github.io/kotonoha-note';
  assert.equal(run(base+'/').status,0); confirmHtml(base);
  assert.ok(!fs.existsSync(path.join(root,'_site','robots.txt')));
  assert.ok(text('sitemap.xml').includes(`${base}/privacy.html`));
});
test('root site generates host-level robots.txt', () => {
  const base='https://example.github.io';
  assert.equal(run(base).status,0); confirmHtml(base);
  assert.ok(text('robots.txt').includes(`Sitemap: ${base}/sitemap.xml`));
});
test('unsafe and malformed base URLs are rejected', () => {
  for (const url of ['bad','javascript:alert(1)','https://alice:secret@example.github.io/path','https://example.github.io/?x=1','https://example.github.io/#x']) assert.notEqual(run(url).status,0,url);
});
