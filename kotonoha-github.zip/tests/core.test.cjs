const test = require('node:test');
const assert = require('node:assert/strict');
const { parseNotes, normalize, itemKey, buildChoices, readBackup, cleanNote } = require('../site/core.js');

test('pasted spreadsheet prefers tabs over punctuation within a term', () => {
  assert.deepEqual(parseNotes('時刻 12:30\t昼食\nred, blue\t色').items, [{term:'時刻 12:30',meaning:'昼食'},{term:'red, blue',meaning:'色'}]);
});
test('explicit separators and meanings containing punctuation', () => {
  assert.deepEqual(parseNotes('apple,りんご: 果物','comma').items,[{term:'apple',meaning:'りんご: 果物'}]);
  assert.equal(parseNotes('用語：意味、説明').items[0].meaning,'意味、説明');
  assert.equal(parseNotes('x\ty','colon').errors.length,1);
});
test('blank lines, incomplete pairs and duplicate pairs give useful results', () => {
  assert.equal(parseNotes('\n \n').items.length,0);
  assert.equal(parseNotes('x:\n:y\nno delimiter').errors.length,3);
  assert.match(parseNotes('x:y\nx:y').errors[0],/2行目.*重複/);
});
test('limits protect large inputs', () => {
  assert.equal(parseNotes('x'.repeat(201)+':y').errors.length,1);
  assert.equal(parseNotes('x:'+'y'.repeat(2001)).errors.length,1);
  assert.equal(parseNotes(Array.from({length:201},(_,i)=>i+':意味').join('\n')).errors.length,1);
});
test('answer normalization accepts fullwidth and ignores spaces', () => { assert.equal(normalize(' Ｃ p Ｕ '), 'cpu'); });
test('choices have one normalized correct answer and no duplicate distractors', () => {
  const items=[{term:'CPU'},{term:'ｃｐｕ'},{term:'RAM'},{term:'OS'},{term:'LAN'},{term:'ROM'}];
  for(let i=0;i<items.length;i++) { const choices=buildChoices(items,i,()=>.4); assert.equal(choices.length,4); assert.equal(new Set(choices.map(normalize)).size,4); assert.ok(choices.includes(items[i].term)); }
});
test('small sets gracefully produce fewer choices', () => { assert.equal(buildChoices([{term:'a'},{term:'A'}],0).length,1); });
test('backup roundtrip preserves draft, generated content and learned state', () => {
  const key=itemKey({term:'a',meaning:'b'});
  const note={title:'学習',source:'未完成',generatedSource:'a:b',mastered:[key],delimiter:'auto'};
  const restored=readBackup(JSON.parse(JSON.stringify({format:'kotonoha-library',version:2,notes:[note]})))[0];
  assert.equal(restored.source,'未完成'); assert.equal(restored.generatedSource,'a:b'); assert.deepEqual(restored.mastered,[key]);
});
test('legacy exported notes are still usable', () => { const note=readBackup({format:'kotonoha-note',version:1,title:'旧',source:'CPU:装置'})[0];assert.equal(note.generatedSource,'CPU:装置'); });
test('malformed backups fail atomically', () => {
  assert.throws(()=>readBackup({format:'other',version:2,notes:[]}));
  assert.throws(()=>readBackup({format:'kotonoha-library',version:2,notes:[{title:'ok',source:'a:b'},{title:42,source:'x:y'}]}));
  assert.throws(()=>readBackup({format:'kotonoha-library',version:2,notes:Array(31).fill({title:'x',source:'a:b'})}));
});
test('unknown progress keys and invalid generated content are not restored', () => {
  const note=cleanNote({title:'x',source:'a:b',generatedSource:'invalid',mastered:['bad']});
  assert.equal(note.generatedSource,''); assert.deepEqual(note.mastered,[]);
});
test('HTML-like content is retained as plain data, never interpreted here', () => { assert.equal(parseNotes('<script> : <img onerror=alert(1)>').items[0].term,'<script>'); });
